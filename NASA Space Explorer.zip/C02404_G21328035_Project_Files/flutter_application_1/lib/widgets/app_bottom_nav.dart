import 'package:flutter/material.dart';
import '../views/home_screen.dart';
import '../views/search_screen.dart';
import '../views/favourites_screen.dart';
import '../views/settings_screen.dart';

// Reusable bottom navigation bar widget used across all main screens
// currentIndex highlights the active tab
class AppBottomNav extends StatelessWidget {
  final int currentIndex;

  const AppBottomNav({super.key, required this.currentIndex});

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      type: BottomNavigationBarType.fixed, // keeps all 4 icons visible

      onTap: (index) {
        // prevent re-navigating to the current screen
        if (index == currentIndex) return;

        Widget page;

        // map each tab index to its corresponding screen
        switch (index) {
          case 0:
            page = const HomeScreen();
            break;
          case 1:
            page = const SearchScreen();
            break;
          case 2:
            page = const FavouritesScreen();
            break;
          case 3:
            page = const SettingsScreen();
            break;
          default:
            return;
        }

        // push new screen onto the navigation stack
        Navigator.push(context, MaterialPageRoute(builder: (_) => page));
      },

      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
        BottomNavigationBarItem(icon: Icon(Icons.favorite), label: "Favourite"),
        BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
      ],
    );
  }
}
