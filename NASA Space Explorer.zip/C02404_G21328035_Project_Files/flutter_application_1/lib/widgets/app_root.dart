import 'package:flutter/material.dart';
import '../views/home_screen.dart';
import '../controllers/settings_controller.dart';

// Root widget of the app — wraps MaterialApp with reactive theme support
// Listens to dark mode and font size changes and rebuilds the entire app theme
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});

  @override
  Widget build(BuildContext context) {
    // listen to dark mode changes — rebuilds app when toggled
    return ValueListenableBuilder<bool>(
      valueListenable: SettingsController.darkModeEnabled,
      builder: (context, isDarkMode, _) {
        // listen to font size changes — rebuilds app when slider changes
        return ValueListenableBuilder<double>(
          valueListenable: SettingsController.fontSize,
          builder: (context, fontSize, _) {
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'NASA Gallery App',

              // light theme applied when dark mode is off
              theme: ThemeData(
                brightness: Brightness.light,
                useMaterial3: true,
                textTheme: _buildTextTheme(fontSize),
              ),

              // dark theme applied when dark mode is on
              darkTheme: ThemeData(
                brightness: Brightness.dark,
                useMaterial3: true,
                textTheme: _buildTextTheme(fontSize),
              ),

              // switches between light and dark based on settings
              themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,

              home: const HomeScreen(),
            );
          },
        );
      },
    );
  }

  // Builds a TextTheme with scaled font sizes based on the user's font size setting
  // All text styles are relative to the base fontSize from settings
  static TextTheme _buildTextTheme(double fontSize) {
    return TextTheme(
      bodyLarge: TextStyle(fontSize: fontSize + 2),
      bodyMedium: TextStyle(fontSize: fontSize),
      bodySmall: TextStyle(fontSize: fontSize - 2),

      titleLarge: TextStyle(
        fontSize: fontSize + 6,
        fontWeight: FontWeight.bold,
      ),

      titleMedium: TextStyle(
        fontSize: fontSize + 4,
        fontWeight: FontWeight.w600,
      ),

      titleSmall: TextStyle(
        fontSize: fontSize + 2,
        fontWeight: FontWeight.w600,
      ),
    );
  }
}
