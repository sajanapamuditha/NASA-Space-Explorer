import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

// Service class for all NASA API communication
// Handles APOD, Image/Video search and video URL fetching
class NasaApiService {
  // API key loaded securely from .env file — never hardcoded
  static String get apiKey => dotenv.env['NASA_API_KEY'] ?? '';

  // APOD (Astronomy Picture of the Day)
  // thumbs=true ensures video entries also return a thumbnail_url
  static Future<Map<String, dynamic>> fetchAPOD() async {
    try {
      if (apiKey.isEmpty) {
        throw Exception("NASA API key missing in .env file");
      }

      final url = Uri.parse(
        "https://api.nasa.gov/planetary/apod?api_key=$apiKey&thumbs=true",
      );

      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data == null) {
          throw Exception("Empty APOD response");
        }

        return data;
      } else {
        throw Exception("APOD API error: ${response.statusCode}");
      }
    } on TimeoutException {
      throw Exception("APOD request timed out. Check your connection.");
    } on http.ClientException {
      throw Exception("No internet connection. Please check your network.");
    } catch (e) {
      throw Exception("Failed to load APOD: $e");
    }
  }

  // Searches NASA Image and Video Library by keyword
  // Query is URL-encoded to handle spaces and special characters
  static Future<List<dynamic>> searchMedia(String query) async {
    try {
      if (query.trim().isEmpty) {
        throw Exception("Search query cannot be empty");
      }

      // encode query to safely handle spaces and special characters in URL
      final encodedQuery = Uri.encodeComponent(query.trim());

      final url = Uri.parse(
        "https://images-api.nasa.gov/search?q=$encodedQuery&media_type=image,video",
      );

      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['collection'] == null || data['collection']['items'] == null) {
          return [];
        }

        return data['collection']['items'];
      } else {
        throw Exception("NASA Search API error: ${response.statusCode}");
      }
    } on TimeoutException {
      throw Exception("Search request timed out. Check your connection.");
    } on http.ClientException {
      throw Exception("No internet connection. Please check your network.");
    } catch (e) {
      throw Exception("Failed to search media: $e");
    }
  }

  // Fetches the direct .mp4 video URL from NASA asset API using NASA ID
  // Priority: ~orig.mp4 (best quality) → ~large.mp4 → any .mp4
  // Returns null if no valid video URL found or request fails
  static Future<String?> fetchVideoUrl(String nasaId) async {
    try {
      final url = Uri.parse("https://images-api.nasa.gov/asset/$nasaId");

      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        final items = data['collection']['items'];

        // try best quality first
        for (var item in items) {
          final String href = item['href'];
          if (href.endsWith("~orig.mp4")) return href;
        }

        // fallback to large
        for (var item in items) {
          final String href = item['href'];
          if (href.endsWith("~large.mp4")) return href;
        }

        // fallback to any mp4
        for (var item in items) {
          final String href = item['href'];
          if (href.endsWith(".mp4")) return href;
        }
      }
    } on TimeoutException {
      print("Video URL fetch timed out for nasaId: $nasaId");
      return null;
    } on http.ClientException {
      print("No internet connection while fetching video URL.");
      return null;
    } catch (e) {
      print("Video fetch error: $e");
    }

    return null;
  }
}
