import 'package:flutter/material.dart';
import '../controllers/favourites_controller.dart';
import '../widgets/app_bottom_nav.dart';

// Screen that displays full details of a selected NASA image
// Allows user to add or remove the image from favourites
class ImageDetailsScreen extends StatefulWidget {
  // unique NASA ID used to check and manage favourite state
  final String id;
  final String title;
  final String imageUrl;
  final String description;

  const ImageDetailsScreen({
    super.key,
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.description,
  });

  @override
  State<ImageDetailsScreen> createState() => _ImageDetailsScreenState();
}

class _ImageDetailsScreenState extends State<ImageDetailsScreen> {
  // tracks whether this image is already saved in favourites
  bool _alreadySaved = false;

  @override
  void initState() {
    super.initState();
    // check if this item is already in favourites when screen opens
    _alreadySaved = FavouritesController.favourites.any(
      (item) => item['id'] == widget.id,
    );
  }

  // handles add or remove favourite based on current saved state
  // messenger is captured before async gap to avoid context issues
  Future<void> _handleFavourite() async {
    // capture messenger before async operation
    final messenger = ScaffoldMessenger.of(context);

    if (_alreadySaved) {
      // remove item from favourites if already saved
      await FavouritesController.removeFavourite(widget.id);

      if (!context.mounted) return;

      setState(() => _alreadySaved = false);

      // show confirmation using pre-captured messenger
      messenger.showSnackBar(
        const SnackBar(
          content: Text("Removed from favourites"),
          backgroundColor: Colors.redAccent,
        ),
      );
    } else {
      // add item to favourites if not already saved
      await FavouritesController.addFavourite(
        id: widget.id,
        title: widget.title,
        mediaUrl: widget.imageUrl,
        thumbnailUrl: widget.imageUrl,
        description: widget.description,
        isVideo: false,
      );

      // check context is still valid after async gap
      if (!context.mounted) return;

      // update UI to reflect saved state
      setState(() => _alreadySaved = true);

      // show confirmation using pre-captured messenger
      messenger.showSnackBar(
        const SnackBar(
          content: Text("Added to favourites ❤️"),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Image Details")),

      body: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height,
        // space-themed background image
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/background.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),

              // full width image displayed in 16:9 aspect ratio with rounded corners
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Image.network(
                      widget.imageUrl,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      // show loading spinner while image fetches from network
                      loadingBuilder: (context, child, loadingProgress) {
                        // return image when fully loaded
                        if (loadingProgress == null) return child;

                        // show spinner while loading
                        return Container(
                          color: Colors.grey.shade800,
                          child: const Center(
                            child: CircularProgressIndicator(
                              color: Colors.white,
                            ),
                          ),
                        );
                      },
                      // show broken image icon if URL fails to load
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.grey.shade800,
                        child: const Center(
                          child: Icon(
                            Icons.broken_image,
                            size: 80,
                            color: Colors.white54,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // content section with title, description and favourite button
              Padding(
                padding: const EdgeInsets.all(16),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10),

                    // image title from NASA API
                    Text(
                      widget.title,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 14, 13, 13),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // image description — fallback text if description is empty
                    Text(
                      widget.description.isNotEmpty
                          ? widget.description
                          : "No description available.",
                      style: const TextStyle(
                        fontSize: 15,
                        height: 1.6,
                        color: Color.fromARGB(179, 14, 13, 13),
                      ),
                    ),

                    const SizedBox(height: 30),

                    // toggle favourite button — changes appearance based on saved state
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        // filled heart if saved, outline heart if not saved
                        icon: Icon(
                          _alreadySaved
                              ? Icons.favorite
                              : Icons.favorite_border,
                          color: _alreadySaved ? Colors.red : Colors.white,
                        ),
                        // label changes based on current saved state
                        label: Text(
                          _alreadySaved
                              ? "Remove from Favourites"
                              : "Add to Favourite",
                          style: const TextStyle(fontSize: 16),
                        ),
                        // button colour changes — grey if saved, blue if not
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _alreadySaved
                              ? Colors.grey.shade800
                              : Colors.blueAccent,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        // calls _handleFavourite to add or remove
                        onPressed: _handleFavourite,
                      ),
                    ),

                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const AppBottomNav(currentIndex: 0),
    );
  }
}
