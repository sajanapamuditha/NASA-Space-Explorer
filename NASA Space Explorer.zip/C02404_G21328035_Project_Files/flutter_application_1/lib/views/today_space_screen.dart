import 'package:flutter/material.dart';
import '../services/api_servise.dart';
import '../widgets/app_bottom_nav.dart';
import '../controllers/favourites_controller.dart';
import 'video_detail_screen.dart';

// Screen that displays NASA's Astronomy Picture of the Day (APOD)
// Supports image and YouTube video APOD entries, favourites toggle and pull-to-refresh
class TodaySpaceScreen extends StatefulWidget {
  const TodaySpaceScreen({super.key});

  @override
  State<TodaySpaceScreen> createState() => _TodaySpaceScreenState();
}

class _TodaySpaceScreenState extends State<TodaySpaceScreen> {
  // tracks whether API call is still in progress
  bool _isLoading = true;
  bool _alreadySaved = false;
  bool _hasError = false;

  // holds the full APOD data returned from NASA API
  Map<String, dynamic>? _apodData;

  @override
  void initState() {
    super.initState();
    // fetch today's APOD when screen first opens
    _loadApod();
  }

  // fetches today's APOD data from NASA API
  // updates state based on success or failure
  Future<void> _loadApod() async {
    try {
      final data = await NasaApiService.fetchAPOD();

      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() {
        _apodData = data;
        _isLoading = false;
        _hasError = false;
        // check if today's APOD is already in favourites using date as ID
        _alreadySaved = FavouritesController.favourites.any(
          (item) => item['id'] == data['date'],
        );
      });
    } catch (e) {
      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _hasError = true; // triggers offline error UI
      });
    }
  }

  // extracts YouTube video ID from both youtube.com and youtu.be URL formats
  // used to build thumbnail URL for YouTube APOD video entries
  String _extractYouTubeId(String url) {
    if (url.contains("youtube.com")) {
      // extract video ID from query parameter 'v'
      final uri = Uri.parse(url);
      return uri.queryParameters['v'] ?? '';
    } else if (url.contains("youtu.be")) {
      // extract video ID from the last segment of the URL
      return url.split('/').last;
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Today's Space")),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/background.png"),
            fit: BoxFit.cover,
          ),
        ),
        // show different UI based on current state
        child: _isLoading
            // loading spinner while APOD data is being fetched
            ? const Center(child: CircularProgressIndicator())
            // offline error UI when no internet connection
            : _hasError
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.wifi_off,
                      size: 64,
                      color: Color.fromARGB(137, 21, 20, 20),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      "No internet connection",
                      style: TextStyle(
                        color: Color.fromARGB(255, 14, 13, 13),
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Check your connection and try again",
                      style: TextStyle(
                        color: Color.fromARGB(179, 20, 20, 20),
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 24),
                    // retry button — resets state and calls _loadApod again
                    ElevatedButton.icon(
                      icon: const Icon(Icons.refresh),
                      label: const Text("Retry"),
                      onPressed: () {
                        setState(() {
                          _isLoading = true;
                          _hasError = false;
                        });
                        _loadApod();
                      },
                    ),
                  ],
                ),
              )
            // fallback if data is null even after successful response
            : _apodData == null
            ? const Center(
                child: Text(
                  "Failed to load data",
                  style: TextStyle(color: Color.fromARGB(255, 23, 23, 23)),
                ),
              )
            // wrap content with RefreshIndicator for pull-to-refresh support
            : RefreshIndicator(onRefresh: _loadApod, child: _buildContent()),
      ),
      bottomNavigationBar: const AppBottomNav(currentIndex: 0),
    );
  }

  // builds the main content — image/video, title, description and favourite button
  // handles both image and YouTube video APOD entries
  Widget _buildContent() {
    // extract fields from APOD API response
    final String id = _apodData!['date'] ?? '';
    final String title = _apodData!['title'] ?? '';
    final String description = _apodData!['explanation'] ?? '';
    final String mediaType = _apodData!['media_type'] ?? 'image';
    final String mediaUrl = _apodData!['url'] ?? '';

    // true if today's APOD is a video instead of an image
    final bool isVideo = mediaType == 'video';

    // determine thumbnail URL — priority: API thumbnail > YouTube thumbnail > mediaUrl
    String thumbnailUrl = '';
    if (_apodData!['thumbnail_url'] != null &&
        _apodData!['thumbnail_url'].toString().isNotEmpty) {
      // use NASA-provided thumbnail if available
      thumbnailUrl = _apodData!['thumbnail_url'];
    } else if (mediaUrl.contains("youtube.com") ||
        mediaUrl.contains("youtu.be")) {
      // build YouTube thumbnail URL from extracted video ID
      final videoId = _extractYouTubeId(mediaUrl);
      if (videoId.isNotEmpty) {
        thumbnailUrl = "https://img.youtube.com/vi/$videoId/0.jpg";
      }
    } else {
      // for non-YouTube videos use mediaUrl directly as thumbnail
      thumbnailUrl = mediaUrl;
    }

    return SingleChildScrollView(
      // required so RefreshIndicator gesture works on all content heights
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // media section — displays image or tappable video thumbnail
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: GestureDetector(
                onTap: () {
                  // only video items are tappable — opens VideoDetailsScreen
                  if (isVideo) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => VideoDetailsScreen(
                          id: id,
                          title: title,
                          videoUrl: mediaUrl,
                          thumbnailUrl: thumbnailUrl,
                          description: description,
                        ),
                      ),
                    );
                  }
                },
                child: isVideo
                    // video — show thumbnail with play icon overlay
                    ? Stack(
                        alignment: Alignment.center,
                        children: [
                          // show thumbnail or black background if URL empty
                          thumbnailUrl.isNotEmpty
                              ? Image.network(
                                  thumbnailUrl,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) =>
                                      Container(color: Colors.black),
                                )
                              : Container(color: Colors.black),
                          // play icon indicates this is a tappable video
                          const Icon(
                            Icons.play_circle_fill,
                            size: 80,
                            color: Colors.white,
                          ),
                        ],
                      )
                    // image — load directly from NASA URL
                    : Image.network(
                        mediaUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: Colors.grey.shade300,
                          child: const Center(
                            child: Icon(Icons.image, size: 80),
                          ),
                        ),
                      ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // APOD title from NASA API response
          Text(
            title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Color.fromARGB(255, 9, 9, 9),
            ),
          ),

          const SizedBox(height: 12),

          // APOD explanation/description from NASA API response
          Text(
            description,
            style: const TextStyle(
              fontSize: 16,
              height: 1.5,
              color: Color.fromARGB(255, 18, 17, 17),
            ),
          ),

          const SizedBox(height: 30),

          // toggle favourite button — appearance changes based on saved state
          SizedBox(
            width: double.infinity,
            height: 45,
            child: ElevatedButton.icon(
              // filled heart if saved, outline heart if not saved
              icon: Icon(
                _alreadySaved ? Icons.favorite : Icons.favorite_border,
                color: _alreadySaved ? Colors.red : Colors.white,
              ),
              // label changes based on current saved state
              label: Text(
                _alreadySaved ? "Remove from Favourites" : "Add to Favourites",
              ),
              // button colour changes — grey if saved, blue if not
              style: ElevatedButton.styleFrom(
                backgroundColor: _alreadySaved
                    ? Colors.grey.shade800
                    : Colors.blueAccent,
                foregroundColor: Colors.white,
              ),
              onPressed: () async {
                if (_alreadySaved) {
                  // remove from favourites and update UI
                  await FavouritesController.removeFavourite(id);
                  if (!mounted) return;
                  setState(() => _alreadySaved = false);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Removed from favourites"),
                      backgroundColor: Colors.redAccent,
                    ),
                  );
                } else {
                  // add to favourites and update UI
                  await FavouritesController.addFavourite(
                    id: id,
                    title: title,
                    mediaUrl: mediaUrl,
                    thumbnailUrl: thumbnailUrl,
                    description: description,
                    isVideo: isVideo,
                  );
                  if (!mounted) return;
                  setState(() => _alreadySaved = true);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Added to favourites ❤️"),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              },
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
