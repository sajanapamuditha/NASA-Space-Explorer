import 'package:flutter/material.dart';
import '../widgets/app_bottom_nav.dart';
import '../controllers/favourites_controller.dart';
import 'image_detail_screen.dart';
import 'video_detail_screen.dart';

// Screen that displays all saved favourite images and videos
// Supports pull-to-refresh, delete with confirmation and empty state
class FavouritesScreen extends StatefulWidget {
  const FavouritesScreen({super.key});

  @override
  State<FavouritesScreen> createState() => _FavouritesScreenState();
}

class _FavouritesScreenState extends State<FavouritesScreen> {
  @override
  void initState() {
    super.initState();
    // load saved favourites from SharedPreferences when screen opens
    _loadFavourites();
  }

  // loads favourites from local storage and rebuilds the UI
  // mounted check prevents setState being called on a disposed widget
  Future<void> _loadFavourites() async {
    await FavouritesController.loadFavourites();
    if (!mounted) return;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // get current in-memory favourites list
    final favourites = FavouritesController.favourites;

    return Scaffold(
      appBar: AppBar(title: const Text("Favourites")),

      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/background.png"),
            fit: BoxFit.cover,
          ),
        ),
        // wrap with RefreshIndicator to support pull-to-refresh
        child: RefreshIndicator(
          onRefresh: _loadFavourites,
          child: favourites.isEmpty
              // empty state — wrapped in scroll view so pull-to-refresh works
              ? SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: SizedBox(
                    // full screen height ensures pull gesture is detectable
                    height: MediaQuery.of(context).size.height,
                    child: const Center(
                      child: Text(
                        "No favourites added",
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),
                )
              // grid view of saved favourite items
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: favourites.length,

                  // required so pull-to-refresh works on the grid
                  physics: const AlwaysScrollableScrollPhysics(),

                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                  ),
                  itemBuilder: (context, index) {
                    final item = favourites[index];

                    // determine if saved item is video or image
                    final bool isVideo = item['isVideo'] ?? false;

                    // videos use thumbnailUrl for preview, images use mediaUrl
                    final String imageUrl = isVideo
                        ? item['thumbnailUrl'] ?? ''
                        : item['mediaUrl'] ?? '';
                    final String title = item['title'] ?? '';
                    final String description = item['description'] ?? '';
                    final String id = item['id'] ?? '';

                    return Stack(
                      children: [
                        // tappable area — opens image or video detail screen
                        GestureDetector(
                          onTap: () {
                            // navigate to correct detail screen based on type
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => isVideo
                                    // video items open VideoDetailsScreen
                                    ? VideoDetailsScreen(
                                        id: id,
                                        title: title,
                                        videoUrl: item['mediaUrl'] ?? '',
                                        thumbnailUrl:
                                            item['thumbnailUrl'] ?? '',
                                        description: description,
                                      )
                                    // image items open ImageDetailsScreen
                                    : ImageDetailsScreen(
                                        id: id,
                                        title: title,
                                        imageUrl: imageUrl,
                                        description: description,
                                      ),
                              ),
                            );
                          },

                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                // show thumbnail or placeholder if URL is empty
                                imageUrl.isNotEmpty
                                    ? Image.network(
                                        imageUrl,
                                        fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) =>
                                            _placeholder(isVideo),
                                      )
                                    : _placeholder(isVideo),

                                // overlay play icon on video items
                                if (isVideo)
                                  const Center(
                                    child: Icon(
                                      Icons.play_circle_fill,
                                      size: 48,
                                      color: Colors.white,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),

                        // delete button positioned top-right of each card
                        Positioned(
                          top: 6,
                          right: 6,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: IconButton(
                              icon: const Icon(
                                Icons.delete,
                                color: Colors.white,
                              ),
                              onPressed: () async {
                                // show confirmation dialog before deleting
                                bool? confirmDelete = await showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      title: const Text("Delete Favourite"),
                                      content: const Text(
                                        "Do you want to delete this item from favourites?",
                                      ),
                                      actions: [
                                        // cancel — returns false to close dialog
                                        TextButton(
                                          onPressed: () {
                                            Navigator.pop(context, false);
                                          },
                                          child: const Text("Cancel"),
                                        ),

                                        // confirm — returns true to trigger delete
                                        ElevatedButton(
                                          onPressed: () {
                                            Navigator.pop(context, true);
                                          },
                                          child: const Text("Delete"),
                                        ),
                                      ],
                                    );
                                  },
                                );

                                // only delete if user confirmed
                                if (confirmDelete == true) {
                                  await FavouritesController.removeFavourite(
                                    id,
                                  );
                                  // check mounted before calling setState
                                  if (!mounted) return;
                                  setState(() {});

                                  // check context.mounted before using context
                                  if (!context.mounted) return;
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        "Item removed from favourites",
                                      ),
                                    ),
                                  );
                                }
                              },
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
        ),
      ),

      bottomNavigationBar: const AppBottomNav(currentIndex: 2),
    );
  }

  // returns a placeholder widget when image URL is missing or fails to load
  // shows different icon depending on whether item is video or image
  Widget _placeholder(bool isVideo) {
    return Container(
      color: Colors.grey.shade300,
      child: Center(
        child: Icon(
          // video items show camera icon, images show image icon
          isVideo ? Icons.videocam : Icons.image,
          size: 40,
          color: Colors.black54,
        ),
      ),
    );
  }
}
