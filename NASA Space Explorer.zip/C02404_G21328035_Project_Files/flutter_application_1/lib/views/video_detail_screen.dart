import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../controllers/favourites_controller.dart';
import '../widgets/app_bottom_nav.dart';

// Screen that displays full details of a selected NASA video
// Supports video playback with play/pause, favourites toggle
class VideoDetailsScreen extends StatefulWidget {
  // unique NASA ID used to check and manage favourite state
  final String id;
  final String title;
  final String videoUrl;
  final String description;
  final String thumbnailUrl;

  const VideoDetailsScreen({
    super.key,
    required this.id,
    required this.title,
    required this.videoUrl,
    required this.description,
    required this.thumbnailUrl,
  });

  @override
  State<VideoDetailsScreen> createState() => _VideoDetailsScreenState();
}

class _VideoDetailsScreenState extends State<VideoDetailsScreen> {
  // controls video playback — null until video is successfully initialised
  VideoPlayerController? _controller;

  bool _videoReady = false;
  bool _videoError = false;
  bool _alreadySaved = false;

  @override
  void initState() {
    super.initState();
    // start video initialisation when screen opens
    initializeVideo();
    // check if this video is already saved in favourites
    _alreadySaved = FavouritesController.favourites.any(
      (item) => item['id'] == widget.id,
    );
  }

  // initialises the VideoPlayerController with the provided video URL
  // only accepts .mp4 URLs — sets error state for any other format
  Future<void> initializeVideo() async {
    // reject non-mp4 URLs immediately without attempting to load
    if (!widget.videoUrl.contains(".mp4")) {
      if (!mounted) return;
      setState(() => _videoError = true);
      return;
    }

    try {
      // create controller from network URL and initialise
      _controller = VideoPlayerController.networkUrl(
        Uri.parse(widget.videoUrl),
      );
      await _controller!.initialize();

      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() => _videoReady = true);
    } catch (e) {
      // initialisation failed — show error message in player area
      if (!mounted) return;
      setState(() => _videoError = true);
    }
  }

  // toggles between play and pause states
  // does nothing if controller is not yet initialised
  void togglePlay() {
    if (_controller == null) return;
    setState(() {
      // pause if playing, play if paused
      _controller!.value.isPlaying ? _controller!.pause() : _controller!.play();
    });
  }

  // handles add or remove favourite based on current saved state
  Future<void> _handleFavourite() async {
    if (_alreadySaved) {
      // remove from favourites and update button state
      await FavouritesController.removeFavourite(widget.id);

      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() => _alreadySaved = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Removed from favourites"),
          backgroundColor: Colors.redAccent,
        ),
      );
    } else {
      // add to favourites — isVideo: true ensures correct display in favourites grid
      await FavouritesController.addFavourite(
        id: widget.id,
        title: widget.title,
        mediaUrl: widget.videoUrl,
        thumbnailUrl: widget.thumbnailUrl,
        description: widget.description,
        isVideo: true,
      );

      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() => _alreadySaved = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Added to favourites ❤️"),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  // dispose video controller to free memory when screen is removed
  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Video Details")),
      bottomNavigationBar: const AppBottomNav(currentIndex: 0),
      body: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height,
        // space-themed background image
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/background.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // video player area — fixed height of 220px
            SizedBox(
              height: 220,
              width: double.infinity,
              child: _videoError
                  // error state — shown when URL is invalid or load fails
                  ? const Center(
                      child: Text(
                        "Video cannot be played",
                        style: TextStyle(fontSize: 16, color: Colors.black),
                      ),
                    )
                  : _videoReady
                  // video is ready — show tappable player with play/pause toggle
                  ? GestureDetector(
                      onTap: togglePlay,
                      child: AspectRatio(
                        aspectRatio: _controller!.value.aspectRatio,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            // actual video player widget
                            VideoPlayer(_controller!),
                            // show play icon overlay only when video is paused
                            if (!_controller!.value.isPlaying)
                              const Icon(
                                Icons.play_circle_fill,
                                size: 80,
                                color: Colors.white,
                              ),
                          ],
                        ),
                      ),
                    )
                  // loading state — shown while video is initialising
                  : const Center(child: CircularProgressIndicator()),
            ),

            const SizedBox(height: 16),

            // video title from NASA API
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                widget.title,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),

            const SizedBox(height: 10),

            // scrollable description — Expanded fills remaining space
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SingleChildScrollView(
                  child: Text(
                    widget.description,
                    style: const TextStyle(
                      fontSize: 16,
                      height: 1.5,
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
            ),

            // favourite toggle button — fixed at bottom above nav bar
            // SafeArea prevents overlap with system UI
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    // filled heart if saved, outline heart if not saved
                    icon: Icon(
                      _alreadySaved ? Icons.favorite : Icons.favorite_border,
                      color: _alreadySaved ? Colors.red : Colors.white,
                    ),
                    // label changes based on current saved state
                    label: Text(
                      _alreadySaved
                          ? "Remove from Favourites"
                          : "Add to Favourite",
                    ),
                    // button colour changes — grey if saved, blue if not
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _alreadySaved
                          ? Colors.grey.shade800
                          : Colors.blueAccent,
                      foregroundColor: Colors.white,
                    ),
                    // calls _handleFavourite to add or remove
                    onPressed: _handleFavourite,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
