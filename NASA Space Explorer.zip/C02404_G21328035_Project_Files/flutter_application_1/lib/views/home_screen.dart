import 'package:flutter/material.dart';
import 'today_space_screen.dart';
import 'explore_gallery_screen.dart';

// Home screen — entry point of the app after launch
// Displays the app logo and two main navigation buttons
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // full screen space-themed background image
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('images/background.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(65),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // CosmicLens app logo displayed as circular avatar
                const CircleAvatar(
                  radius: 60,
                  backgroundImage: AssetImage('images/nasa_gallery_logo.png'),
                ),

                const SizedBox(height: 40),

                // button 1 — navigates to Today's Space Photo screen
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 48),
                    side: const BorderSide(
                      color: Color.fromARGB(255, 16, 16, 16),
                    ),
                    foregroundColor: const Color.fromARGB(255, 24, 24, 24),
                  ),
                  onPressed: () {
                    // push TodaySpaceScreen onto navigation stack
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const TodaySpaceScreen(),
                      ),
                    );
                  },
                  child: const Text("Today's Space Photo"),
                ),

                const SizedBox(height: 35),

                // button 2 — navigates to Explore NASA Gallery screen
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 48),
                    side: const BorderSide(
                      color: Color.fromARGB(255, 21, 20, 20),
                    ),
                    foregroundColor: const Color.fromARGB(255, 23, 20, 20),
                  ),
                  onPressed: () {
                    // push ExploreGalleryScreen onto navigation stack
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ExploreGalleryScreen(),
                      ),
                    );
                  },
                  child: const Text("Explore NASA Gallery"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
