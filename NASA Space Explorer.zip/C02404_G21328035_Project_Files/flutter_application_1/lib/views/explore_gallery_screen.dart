import 'package:flutter/material.dart';
import '../services/api_servise.dart';
import '../widgets/app_bottom_nav.dart';
import 'image_detail_screen.dart';
import 'video_detail_screen.dart';

// Screen that displays a scrollable grid of NASA images and videos
// Supports infinite scroll, pull-to-refresh and offline error handling
class ExploreGalleryScreen extends StatefulWidget {
  const ExploreGalleryScreen({super.key});

  @override
  State<ExploreGalleryScreen> createState() => _ExploreGalleryScreenState();
}

class _ExploreGalleryScreenState extends State<ExploreGalleryScreen> {
  // controls scroll position and detects when user reaches bottom
  final ScrollController _scrollController = ScrollController();

  // holds all fetched NASA media items
  List<dynamic> _items = [];

  // tracks loading and error states for UI rendering
  bool _isLoading = true;
  bool _hasError = false;
  int _visibleCount = 20;

  @override
  void initState() {
    super.initState();

    // load initial media when screen opens
    loadMedia();

    // listen for scroll — load more items when near the bottom
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 200) {
        loadMore();
      }
    });
  }

  // fetches NASA media from API and updates state
  // resets error flag on each attempt to allow retry
  Future<void> loadMedia() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    try {
      final results = await NasaApiService.searchMedia("space");

      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() {
        _items = results;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint("Explore error: $e");

      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _hasError = true; // triggers offline error UI
      });
    }
  }

  // loads 20 more items into the visible grid
  // does nothing if all items are already visible
  void loadMore() {
    if (_visibleCount >= _items.length) return;

    setState(() {
      _visibleCount += 20;
    });
  }

  // fallback widget shown when image fails to load
  Widget placeholder() {
    return Container(
      color: Colors.grey.shade300,
      child: const Center(child: Icon(Icons.image, size: 40)),
    );
  }

  // handles tap on a grid item — opens image or video detail screen
  // shows loading dialog while fetching video URL for video items
  Future<void> openMedia(
    BuildContext context,
    bool isVideo,
    String id,
    String title,
    String description,
    String imageUrl,
  ) async {
    if (isVideo) {
      // show loading spinner while fetching real video URL
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(child: CircularProgressIndicator()),
      );

      try {
        String? videoUrl = await NasaApiService.fetchVideoUrl(id);

        // dismiss loading dialog after async fetch
        if (!context.mounted) return;
        Navigator.pop(context);

        // inform user if no valid video URL was found
        if (videoUrl == null) {
          if (!context.mounted) return;
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(const SnackBar(content: Text("Video not available")));
          return;
        }

        // navigate to video detail screen with fetched URL
        if (!context.mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => VideoDetailsScreen(
              id: id,
              title: title,
              videoUrl: videoUrl,
              thumbnailUrl: imageUrl,
              description: description,
            ),
          ),
        );
      } catch (e) {
        // dismiss dialog and show error message if fetch fails
        if (!context.mounted) return;
        Navigator.pop(context);

        if (!context.mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("Failed to load video")));
      }
    } else {
      // navigate directly to image detail screen
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ImageDetailsScreen(
            id: id,
            title: title,
            imageUrl: imageUrl,
            description: description,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Explore NASA Gallery")),

      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/background.png"),
            fit: BoxFit.cover,
          ),
        ),

        // show loading, error or grid depending on current state
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _hasError
            // offline error UI with retry button
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.wifi_off,
                      size: 64,
                      color: Color.fromARGB(137, 12, 12, 12),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      "No internet connection",
                      style: TextStyle(
                        color: Color.fromARGB(255, 16, 16, 16),
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Check your connection and try again",
                      style: TextStyle(
                        color: Color.fromARGB(179, 9, 9, 9),
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 24),
                    // retry button calls loadMedia again
                    ElevatedButton.icon(
                      icon: const Icon(Icons.refresh),
                      label: const Text("Retry"),
                      onPressed: loadMedia,
                    ),
                  ],
                ),
              )
            // wrap grid with RefreshIndicator for pull-to-refresh support
            : RefreshIndicator(
                onRefresh: loadMedia,
                child: GridView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(12),

                  // required so RefreshIndicator works even on short content
                  physics: const AlwaysScrollableScrollPhysics(),

                  // show only _visibleCount items for lazy loading
                  itemCount: _items.length < _visibleCount
                      ? _items.length
                      : _visibleCount,

                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),

                  itemBuilder: (context, index) {
                    final item = _items[index];
                    final data = item['data'][0];

                    // determine if this item is a video or image
                    final String mediaType = data['media_type'] ?? "image";
                    final bool isVideo = mediaType == "video";

                    final String id = data['nasa_id'] ?? "";
                    final String title = data['title'] ?? "";
                    final String description = data['description'] ?? "";

                    // use first link as thumbnail — fallback to empty string
                    final String thumbnailUrl =
                        (item['links'] != null && item['links'].isNotEmpty)
                        ? item['links'][0]['href']
                        : "";

                    return GestureDetector(
                      // open image or video on tap
                      onTap: () => openMedia(
                        context,
                        isVideo,
                        id,
                        title,
                        description,
                        thumbnailUrl,
                      ),

                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),

                        child: Stack(
                          fit: StackFit.expand,

                          children: [
                            // show thumbnail or placeholder if URL is empty
                            thumbnailUrl.isNotEmpty
                                ? Image.network(
                                    thumbnailUrl,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => placeholder(),
                                  )
                                : placeholder(),

                            // overlay play icon on video items
                            if (isVideo)
                              const Center(
                                child: Icon(
                                  Icons.play_circle_fill,
                                  size: 50,
                                  color: Colors.white,
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
      ),

      bottomNavigationBar: const AppBottomNav(currentIndex: 0),
    );
  }
}
