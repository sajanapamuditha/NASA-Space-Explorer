import 'package:flutter/material.dart';
import '../widgets/app_bottom_nav.dart';
import '../controllers/settings_controller.dart';

// Screen for managing app preferences
// Controls notifications, dark mode and font size — all persisted to SharedPreferences
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  void initState() {
    super.initState();
    // load saved settings from SharedPreferences when screen opens
    SettingsController.loadSettings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Settings")),

      body: Stack(
        children: [
          // full screen background image behind settings list
          Positioned.fill(
            child: Image.asset("images/background.png", fit: BoxFit.cover),
          ),

          // scrollable settings list on top of background
          ListView(
            padding: const EdgeInsets.all(12),
            children: [
              // NOTIFICATIONS TOGGLE
              // ValueListenableBuilder rebuilds only this tile when value changes
              ValueListenableBuilder<bool>(
                valueListenable: SettingsController.notificationsEnabled,
                builder: (context, enabled, _) {
                  return SwitchListTile(
                    secondary: const Icon(
                      Icons.notifications,
                      color: Colors.black,
                    ),

                    title: const Text(
                      "Notifications",
                      style: TextStyle(color: Colors.black),
                    ),

                    // subtitle shows current enabled or disabled state
                    subtitle: Text(
                      enabled ? "Enabled" : "Disabled",
                      style: const TextStyle(color: Colors.black),
                    ),

                    value: enabled,

                    // called when user toggles the notifications switch
                    onChanged: (value) async {
                      // capture messenger before async gap
                      final messenger = ScaffoldMessenger.of(context);

                      // persist new notification setting to SharedPreferences
                      await SettingsController.saveNotifications(value);

                      // check widget is still mounted before calling setState
                      if (!mounted) return;
                      setState(() {});

                      // show confirmation using pre-captured messenger
                      messenger.showSnackBar(
                        SnackBar(
                          duration: const Duration(seconds: 1),
                          content: Text(
                            value
                                ? "Notifications enabled"
                                : "Notifications disabled",
                          ),
                        ),
                      );
                    },
                  );
                },
              ),

              const Divider(),

              // DARK MODE TOGGLE
              // ValueListenableBuilder rebuilds only this tile when value changes
              ValueListenableBuilder<bool>(
                valueListenable: SettingsController.darkModeEnabled,
                builder: (context, enabled, _) {
                  return SwitchListTile(
                    secondary: const Icon(Icons.dark_mode, color: Colors.black),

                    title: const Text(
                      "Dark Mode",
                      style: TextStyle(color: Colors.black),
                    ),

                    value: enabled,

                    // called when user toggles the dark mode switch
                    onChanged: (value) async {
                      // capture messenger before async gap
                      final messenger = ScaffoldMessenger.of(context);

                      // persist new dark mode setting — AppRoot rebuilds theme reactively
                      await SettingsController.saveDarkMode(value);

                      // check widget is still mounted before calling setState
                      if (!mounted) return;
                      setState(() {});

                      // show confirmation using pre-captured messenger
                      messenger.showSnackBar(
                        SnackBar(
                          duration: const Duration(seconds: 1),
                          content: Text(
                            value ? "Dark mode enabled" : "Dark mode disabled",
                          ),
                        ),
                      );
                    },
                  );
                },
              ),

              const Divider(),

              // font size section title
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  "Font Size",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),

              // FONT SIZE SLIDER
              // ValueListenableBuilder rebuilds only this section when size changes
              ValueListenableBuilder<double>(
                valueListenable: SettingsController.fontSize,
                builder: (context, size, _) {
                  return Column(
                    children: [
                      // slider range 12 to 22 with 10 steps
                      Slider(
                        value: size,
                        min: 12,
                        max: 22,
                        divisions: 10,
                        label: size.toInt().toString(),

                        // called on every slider movement
                        onChanged: (value) async {
                          // persist new font size — AppRoot applies it globally
                          await SettingsController.saveFontSize(value);

                          // check widget is still mounted before calling setState
                          if (!mounted) return;
                          setState(() {});
                        },
                      ),

                      // displays current font size value below the slider
                      Text(
                        "Size: ${size.toInt()} px",
                        style: const TextStyle(color: Colors.black),
                      ),
                    ],
                  );
                },
              ),

              const Divider(),

              // ABOUT section — displays app name and version
              const ListTile(
                leading: Icon(Icons.info, color: Colors.black),

                title: Text("About App", style: TextStyle(color: Colors.black)),

                // app version info
                subtitle: Text(
                  "NASA Gallery App v1.0",
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ],
          ),
        ],
      ),

      // active tab index 3 = Settings
      bottomNavigationBar: const AppBottomNav(currentIndex: 3),
    );
  }
}
