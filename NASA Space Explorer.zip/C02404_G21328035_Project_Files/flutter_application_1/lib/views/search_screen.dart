import 'package:flutter/material.dart';
import '../services/api_servise.dart';
import '../widgets/app_bottom_nav.dart';
import 'image_detail_screen.dart';
import 'video_detail_screen.dart';

// Screen for searching NASA images and videos
// Supports live search, infinite scroll, offline error handling
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  // controls the search text input field
  final TextEditingController _controller = TextEditingController();

  // controls scroll position and detects when user reaches bottom
  final ScrollController _scrollController = ScrollController();

  // holds all results fetched from the API
  List<dynamic> _allResults = [];

  // holds only the currently visible subset of results
  List<dynamic> _visibleResults = [];
  bool _hasSearched = false;
  bool _isLoading = false;
  bool _hasError = false;
  int _itemsToShow = 20;

  @override
  void initState() {
    super.initState();

    // listen for scroll — load more items when near the bottom
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 200) {
        _loadMore();
      }
    });
  }

  // called on every keystroke — searches NASA API with current query
  // resets state if query is empty
  Future<void> _search(String query) async {
    // clear results and reset state when search bar is empty
    if (query.trim().isEmpty) {
      setState(() {
        _hasSearched = false;
        _hasError = false;
        _allResults.clear();
        _visibleResults.clear();
      });
      return;
    }

    // set loading state and reset error and item count before search
    setState(() {
      _hasSearched = true;
      _isLoading = true;
      _hasError = false;
      _itemsToShow = 20;
    });

    try {
      final results = await NasaApiService.searchMedia(query);

      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() {
        _allResults = results;
        // show only first 20 items — rest loaded on scroll
        _visibleResults = _allResults.take(_itemsToShow).toList();
        _isLoading = false;
      });
    } catch (e) {
      // check widget is still mounted before updating state
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _hasError = true; // triggers offline error UI
      });
    }
  }

  // loads 20 more items into visible results when user scrolls near bottom
  // does nothing if all results are already visible
  void _loadMore() {
    if (_visibleResults.length >= _allResults.length) return;

    setState(() {
      _itemsToShow += 20;
      _visibleResults = _allResults.take(_itemsToShow).toList();
    });
  }

  // dispose controllers to free memory when screen is removed
  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Search")),

      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/background.png"),
            fit: BoxFit.cover,
          ),
        ),

        child: Padding(
          padding: const EdgeInsets.all(12),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // search bar — triggers live search on every keystroke
              TextField(
                controller: _controller,
                onChanged: _search,
                // text colour adapts to light/dark mode
                style: TextStyle(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? const Color.fromARGB(255, 32, 31, 31)
                      : Colors.black,
                ),
                decoration: InputDecoration(
                  hintText: "Search NASA images or videos",
                  // hint colour adapts to light/dark mode
                  hintStyle: TextStyle(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? const Color.fromARGB(153, 28, 27, 27)
                        : Colors.black54,
                  ),
                  // icon colour adapts to light/dark mode
                  prefixIcon: Icon(
                    Icons.search,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? const Color.fromARGB(179, 11, 11, 11)
                        : Colors.black54,
                  ),
                  filled: true,
                  // fill colour adapts to light/dark mode
                  fillColor: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white12
                      : const Color.fromARGB(
                          255,
                          214,
                          205,
                          205,
                        ).withOpacity(0.9),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // result label — only shown after search and when no error
              if (_hasSearched && !_hasError)
                const Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Text(
                    "Result",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 18, 17, 17),
                    ),
                  ),
                ),

              // results area — shows different UI based on current state
              Expanded(
                child: !_hasSearched
                    // prompt shown before user starts typing
                    ? const Center(
                        child: Text(
                          "Start typing to search NASA media",
                          style: TextStyle(
                            color: Color.fromARGB(255, 152, 49, 49),
                          ),
                        ),
                      )
                    // loading spinner while API call is in progress
                    : _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    // offline error UI with retry button
                    : _hasError
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.wifi_off,
                              size: 64,
                              color: Color.fromARGB(137, 15, 15, 15),
                            ),
                            const SizedBox(height: 16),
                            const Text(
                              "No internet connection",
                              style: TextStyle(
                                color: Color.fromARGB(255, 26, 25, 25),
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              "Check your connection and try again",
                              style: TextStyle(
                                color: Color.fromARGB(179, 10, 10, 10),
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 24),
                            // retry button re-runs search with current query
                            ElevatedButton.icon(
                              icon: const Icon(Icons.refresh),
                              label: const Text("Retry"),
                              onPressed: () => _search(_controller.text),
                            ),
                          ],
                        ),
                      )
                    // empty state when API returns no results
                    : _visibleResults.isEmpty
                    ? const Center(
                        child: Text(
                          "No results found",
                          style: TextStyle(
                            color: Color.fromARGB(255, 27, 26, 26),
                          ),
                        ),
                      )
                    // grid of search results
                    : GridView.builder(
                        controller: _scrollController,
                        itemCount: _visibleResults.length,
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisSpacing: 12,
                              crossAxisSpacing: 12,
                            ),
                        itemBuilder: (context, index) {
                          final item = _visibleResults[index];
                          final data = item['data'][0];

                          // determine if result is image or video
                          final bool isVideo = data['media_type'] == 'video';

                          final String id = data['nasa_id']?.toString() ?? '';
                          final String title = data['title']?.toString() ?? '';
                          final String description =
                              data['description']?.toString() ?? '';

                          // use first link as thumbnail URL
                          final String imageUrl =
                              (item['links'] != null &&
                                  item['links'].isNotEmpty)
                              ? item['links'][0]['href']
                              : '';

                          return GestureDetector(
                            // handle tap — open image or fetch and open video
                            onTap: () async {
                              if (isVideo) {
                                // show loading dialog while fetching video URL
                                showDialog(
                                  context: context,
                                  barrierDismissible: false,
                                  builder: (_) => const Center(
                                    child: CircularProgressIndicator(),
                                  ),
                                );

                                try {
                                  String? videoUrl =
                                      await NasaApiService.fetchVideoUrl(id);

                                  // dismiss dialog after async fetch
                                  if (!context.mounted) return;
                                  Navigator.pop(context);

                                  // inform user if no video URL found
                                  if (videoUrl == null) {
                                    if (!context.mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text("Video not available"),
                                      ),
                                    );
                                    return;
                                  }

                                  // navigate to video detail screen
                                  if (!context.mounted) return;
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => VideoDetailsScreen(
                                        id: id,
                                        title: title,
                                        videoUrl: videoUrl,
                                        thumbnailUrl: imageUrl,
                                        description: description,
                                      ),
                                    ),
                                  );
                                } catch (e) {
                                  // dismiss dialog and show error on failure
                                  if (!context.mounted) return;
                                  Navigator.pop(context);

                                  if (!context.mounted) return;
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text("Failed to load video"),
                                    ),
                                  );
                                }
                              } else {
                                // navigate directly to image detail screen
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => ImageDetailsScreen(
                                      id: id,
                                      title: title,
                                      imageUrl: imageUrl,
                                      description: description,
                                    ),
                                  ),
                                );
                              }
                            },
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  // show thumbnail or placeholder if URL missing
                                  imageUrl.isNotEmpty
                                      ? Image.network(
                                          imageUrl,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) =>
                                              _placeholder(isVideo),
                                        )
                                      : _placeholder(isVideo),

                                  // overlay play icon on video items
                                  if (isVideo)
                                    const Center(
                                      child: Icon(
                                        Icons.play_circle_fill,
                                        size: 48,
                                        color: Color.fromARGB(
                                          255,
                                          255,
                                          255,
                                          255,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),

      bottomNavigationBar: const AppBottomNav(currentIndex: 1),
    );
  }

  // fallback placeholder widget shown when image URL is empty or fails
  // shows different icon for video vs image items
  Widget _placeholder(bool isVideo) {
    return Container(
      color: const Color.fromARGB(255, 174, 30, 30),
      child: Center(
        child: Icon(
          // video items show camera icon, images show image icon
          isVideo ? Icons.videocam : Icons.image,
          size: 40,
          color: const Color.fromARGB(137, 196, 39, 39),
        ),
      ),
    );
  }
}
