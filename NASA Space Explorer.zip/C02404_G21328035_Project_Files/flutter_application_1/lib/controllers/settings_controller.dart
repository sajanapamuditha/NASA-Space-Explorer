import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsController {
  static final ValueNotifier<bool> notificationsEnabled = ValueNotifier(true);
  static final ValueNotifier<bool> darkModeEnabled = ValueNotifier(false);
  static final ValueNotifier<double> fontSize = ValueNotifier(16);

  // LOAD SETTINGS
  static Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();

    notificationsEnabled.value = prefs.getBool("notifications") ?? true;

    darkModeEnabled.value = prefs.getBool("darkMode") ?? false;

    fontSize.value = prefs.getDouble("fontSize") ?? 16;
  }

  // SAVE NOTIFICATION
  static Future<void> saveNotifications(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("notifications", value);

    notificationsEnabled.value = value;
  }

  // SAVE DARK MODE
  static Future<void> saveDarkMode(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("darkMode", value);

    darkModeEnabled.value = value;
  }

  // SAVE FONT SIZE
  static Future<void> saveFontSize(double value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble("fontSize", value);

    fontSize.value = value;
  }
}
