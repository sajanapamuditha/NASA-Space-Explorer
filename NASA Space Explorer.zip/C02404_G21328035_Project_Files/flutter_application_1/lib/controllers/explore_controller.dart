import '../services/api_servise.dart';

// Controller for the Explore Gallery screen
// Handles fetching NASA images and videos from the Image Library API
class ExploreController {
  // Fetches NASA media items for the gallery
  // Default query is "space" — returns empty list on error to prevent crash
  static Future<List<dynamic>> fetchExploreMedia({
    String query = "space",
  }) async {
    try {
      final results = await NasaApiService.searchMedia(query);

      return results;
    } catch (e) {
      print("Explore fetch error: $e");

      return []; // return empty list so UI shows empty state instead of crashing
    }
  }

  // Fetches the actual .mp4 video URL from NASA asset API using the NASA ID
  // Returns null if no valid video URL is found
  static Future<String?> fetchVideoUrl(String nasaId) async {
    try {
      final videoUrl = await NasaApiService.fetchVideoUrl(nasaId);

      return videoUrl;
    } catch (e) {
      print("Video fetch error: $e");

      return null; // null tells the UI to show "video not available"
    }
  }
}
