import '../services/api_servise.dart';

class SearchController {
  // Search NASA media by query
  static Future<List<dynamic>> search(String query) async {
    if (query.trim().isEmpty) {
      return [];
    }

    return await NasaApiService.searchMedia(query);
  }
}
