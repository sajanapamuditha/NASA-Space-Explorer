import '../services/api_servise.dart';

// Controller for fetching NASA Astronomy Picture of the Day (APOD)
class ApodController {
  // Fetches today's APOD data from the NASA API
  // Returns null if the request fails — UI handles the null state
  static Future<Map<String, dynamic>?> getApod() async {
    try {
      return await NasaApiService.fetchAPOD();
    } catch (e) {
      print("APOD fetch error: $e");
      return null; // let the UI handle null gracefully
    }
  }
}
