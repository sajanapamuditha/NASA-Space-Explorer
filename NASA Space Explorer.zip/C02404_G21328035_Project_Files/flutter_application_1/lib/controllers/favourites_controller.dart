import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

// Controller for managing saved favourite items
class FavouritesController {
  // In-memory list of favourites — loaded from storage on app start
  static List<Map<String, dynamic>> _favourites = [];

  static List<Map<String, dynamic>> get favourites => _favourites;

  // Key used to store favourites in SharedPreferences
  static const String _storageKey = "favourites";

  // LOAD favourites from SharedPreferences
  static Future<void> loadFavourites() async {
    final prefs = await SharedPreferences.getInstance();

    final String? data = prefs.getString(_storageKey);

    if (data != null) {
      final List decoded = jsonDecode(data);

      _favourites = decoded.map((e) => Map<String, dynamic>.from(e)).toList();
    }
  }

  // SAVE favourites to SharedPreferences
  // Private — called automatically after every add or remove
  static Future<void> _saveFavourites() async {
    final prefs = await SharedPreferences.getInstance();

    final String data = jsonEncode(_favourites);

    await prefs.setString(_storageKey, data);
  }

  // Adds a new item to favourites
  // Prevents duplicates — silently returns if item with same id already exists
  static Future<void> addFavourite({
    required String id,
    required String title,
    required String mediaUrl,
    required String description,
    required bool isVideo,
    required String thumbnailUrl,
  }) async {
    final exists = _favourites.any((item) => item['id'] == id);
    if (exists) return; // duplicate check — same id means already saved

    _favourites.add({
      'id': id,
      'title': title,
      'mediaUrl': mediaUrl,
      'thumbnailUrl': thumbnailUrl,
      'description': description,
      'isVideo': isVideo,
    });

    await _saveFavourites();
  }

  // REMOVE favourite by id and persist the updated list
  static Future<void> removeFavourite(String id) async {
    _favourites.removeWhere((item) => item['id'] == id);

    await _saveFavourites();
  }
}
