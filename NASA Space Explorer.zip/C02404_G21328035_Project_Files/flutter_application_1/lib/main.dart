import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'widgets/app_root.dart';
import 'controllers/favourites_controller.dart';
import 'controllers/settings_controller.dart';

// App entry point — initialises all required services before launching the UI
Future<void> main() async {
  // ensures Flutter engine is ready before any async operations
  WidgetsFlutterBinding.ensureInitialized();

  // Load environment variables (NASA API key) from .env file
  await dotenv.load(fileName: ".env");

  // Load saved favourites and settings from SharedPreferences before app starts
  await FavouritesController.loadFavourites();
  await SettingsController.loadSettings();

  // launch the app only after all data is ready
  runApp(const CosmicLensApp());
}

// wraps AppRoot which handles theme and navigation
class CosmicLensApp extends StatelessWidget {
  const CosmicLensApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "CosmicLens",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const AppRoot(),
    );
  }
}
