// Model class representing the app settings
// Holds notification, dark mode and font size preferences
class SettingsModel {
  bool notificationsEnabled;
  bool darkModeEnabled;
  double fontSize;

  SettingsModel({
    required this.notificationsEnabled,
    required this.darkModeEnabled,
    required this.fontSize,
  });

  // Default settings — used when app launches for the first time
  factory SettingsModel.defaults() {
    return SettingsModel(
      notificationsEnabled: true,
      darkModeEnabled: false,
      fontSize: 16.0,
    );
  }

  // Convert model to Map for storing in SharedPreferences
  Map<String, dynamic> toMap() {
    return {
      'notificationsEnabled': notificationsEnabled,
      'darkModeEnabled': darkModeEnabled,
      'fontSize': fontSize,
    };
  }

  // Create model from Map retrieved from SharedPreferences
  // .toDouble() ensures fontSize is always a double even if stored as int
  factory SettingsModel.fromMap(Map<String, dynamic> map) {
    return SettingsModel(
      notificationsEnabled: map['notificationsEnabled'] ?? true,
      darkModeEnabled: map['darkModeEnabled'] ?? false,
      fontSize: (map['fontSize'] ?? 16.0).toDouble(),
    );
  }
}
