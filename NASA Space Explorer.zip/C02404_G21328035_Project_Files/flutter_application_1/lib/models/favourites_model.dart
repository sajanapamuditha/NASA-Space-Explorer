// Model class representing a saved favourite item (image or video)
class FavouriteModel {
  final String id;
  final String title;
  final String mediaUrl;
  final String thumbnailUrl;
  final String description;
  final bool isVideo;

  FavouriteModel({
    required this.id,
    required this.title,
    required this.mediaUrl,
    required this.thumbnailUrl,
    required this.description,
    required this.isVideo,
  });

  // Converts model to Map for storing in SharedPreferences
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'mediaUrl': mediaUrl,
      'thumbnailUrl': thumbnailUrl,
      'description': description,
      'isVideo': isVideo,
    };
  }

  // Creates a FavouriteModel from a Map retrieved from SharedPreferences
  // Uses ?? fallbacks to prevent null crashes on missing fields
  factory FavouriteModel.fromMap(Map<String, dynamic> map) {
    return FavouriteModel(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      mediaUrl: map['mediaUrl'] ?? '',
      thumbnailUrl: map['thumbnailUrl'] ?? '',
      description: map['description'] ?? '',
      isVideo: map['isVideo'] ?? false,
    );
  }
}
