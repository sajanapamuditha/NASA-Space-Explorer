import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_application_1/widgets/app_bottom_nav.dart';
import 'package:flutter_application_1/widgets/app_root.dart';
import 'package:flutter_application_1/controllers/favourites_controller.dart';
import 'package:flutter_application_1/controllers/settings_controller.dart';

void main() {
  // UNIT TESTS — FavouritesController

  group('FavouritesController Unit Tests', () {
    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      FavouritesController.favourites.clear();
    });

    test('Favourites list is empty at start', () {
      expect(FavouritesController.favourites, isEmpty);
    });

    test('Add a favourite item', () async {
      await FavouritesController.addFavourite(
        id: 'test-001',
        title: 'Test Space Image',
        mediaUrl: 'https://example.com/image.jpg',
        thumbnailUrl: 'https://example.com/thumb.jpg',
        description: 'A test space image description.',
        isVideo: false,
      );

      expect(FavouritesController.favourites.length, 1);
      expect(FavouritesController.favourites[0]['id'], 'test-001');
      expect(FavouritesController.favourites[0]['title'], 'Test Space Image');
    });

    test('Prevent duplicate favourites', () async {
      await FavouritesController.addFavourite(
        id: 'test-001',
        title: 'Test Space Image',
        mediaUrl: 'https://example.com/image.jpg',
        thumbnailUrl: 'https://example.com/thumb.jpg',
        description: 'A test description.',
        isVideo: false,
      );

      await FavouritesController.addFavourite(
        id: 'test-001',
        title: 'Test Space Image',
        mediaUrl: 'https://example.com/image.jpg',
        thumbnailUrl: 'https://example.com/thumb.jpg',
        description: 'A test description.',
        isVideo: false,
      );

      expect(FavouritesController.favourites.length, 1);
    });

    test('Remove a favourite item', () async {
      await FavouritesController.addFavourite(
        id: 'test-002',
        title: 'Another Image',
        mediaUrl: 'https://example.com/image2.jpg',
        thumbnailUrl: 'https://example.com/thumb2.jpg',
        description: 'Another description.',
        isVideo: false,
      );

      expect(FavouritesController.favourites.length, 1);

      await FavouritesController.removeFavourite('test-002');

      expect(FavouritesController.favourites, isEmpty);
    });

    test('Add multiple favourites', () async {
      await FavouritesController.addFavourite(
        id: 'test-001',
        title: 'Image One',
        mediaUrl: 'https://example.com/1.jpg',
        thumbnailUrl: 'https://example.com/t1.jpg',
        description: 'Description one.',
        isVideo: false,
      );

      await FavouritesController.addFavourite(
        id: 'test-002',
        title: 'Video One',
        mediaUrl: 'https://example.com/1.mp4',
        thumbnailUrl: 'https://example.com/t2.jpg',
        description: 'Description two.',
        isVideo: true,
      );

      expect(FavouritesController.favourites.length, 2);
    });

    test('Favourite item stores isVideo correctly', () async {
      await FavouritesController.addFavourite(
        id: 'video-001',
        title: 'Space Video',
        mediaUrl: 'https://example.com/video.mp4',
        thumbnailUrl: 'https://example.com/thumb.jpg',
        description: 'A space video.',
        isVideo: true,
      );

      expect(FavouritesController.favourites[0]['isVideo'], true);
    });

    test('Remove non-existent item does not crash', () async {
      await FavouritesController.removeFavourite('non-existent-id');
      expect(FavouritesController.favourites, isEmpty);
    });
  });

  // UNIT TESTS — SettingsController

  group('SettingsController Unit Tests', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });

    test('Default dark mode is false', () {
      expect(SettingsController.darkModeEnabled.value, false);
    });

    test('Default font size is 16', () {
      expect(SettingsController.fontSize.value, 16.0);
    });

    test('Default notifications is true', () {
      expect(SettingsController.notificationsEnabled.value, true);
    });

    test('Dark mode ValueNotifier updates correctly', () {
      SettingsController.darkModeEnabled.value = true;
      expect(SettingsController.darkModeEnabled.value, true);
      SettingsController.darkModeEnabled.value = false;
      expect(SettingsController.darkModeEnabled.value, false);
    });

    test('Font size ValueNotifier updates correctly', () {
      SettingsController.fontSize.value = 20.0;
      expect(SettingsController.fontSize.value, 20.0);
      SettingsController.fontSize.value = 16.0;
    });

    test('Notifications ValueNotifier updates correctly', () {
      SettingsController.notificationsEnabled.value = false;
      expect(SettingsController.notificationsEnabled.value, false);
      SettingsController.notificationsEnabled.value = true;
    });
  });

  // WIDGET TESTS — AppBottomNav
  group('AppBottomNav Widget Tests', () {
    testWidgets('AppBottomNav renders 4 navigation items', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(bottomNavigationBar: AppBottomNav(currentIndex: 0)),
        ),
      );

      expect(find.text('Home'), findsOneWidget);
      expect(find.text('Search'), findsOneWidget);
      expect(find.text('Favourite'), findsOneWidget);
      expect(find.text('Settings'), findsOneWidget);
    });

    testWidgets('AppBottomNav shows correct active index — Home', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(bottomNavigationBar: AppBottomNav(currentIndex: 0)),
        ),
      );

      final nav = tester.widget<BottomNavigationBar>(
        find.byType(BottomNavigationBar),
      );
      expect(nav.currentIndex, 0);
    });

    testWidgets('AppBottomNav shows correct active index — Favourite', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(bottomNavigationBar: AppBottomNav(currentIndex: 2)),
        ),
      );

      final nav = tester.widget<BottomNavigationBar>(
        find.byType(BottomNavigationBar),
      );
      expect(nav.currentIndex, 2);
    });

    testWidgets('AppBottomNav renders all icons', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(bottomNavigationBar: AppBottomNav(currentIndex: 0)),
        ),
      );

      expect(find.byIcon(Icons.home), findsOneWidget);
      expect(find.byIcon(Icons.search), findsOneWidget);
      expect(find.byIcon(Icons.favorite), findsOneWidget);
      expect(find.byIcon(Icons.settings), findsOneWidget);
    });
  });

  // WIDGET TESTS — AppRoot
  group('AppRoot Widget Tests', () {
    testWidgets('AppRoot renders MaterialApp', (WidgetTester tester) async {
      await tester.pumpWidget(const AppRoot());
      await tester.pump();
      expect(find.byType(MaterialApp), findsOneWidget);
    });

    testWidgets('AppRoot uses light theme by default', (
      WidgetTester tester,
    ) async {
      SettingsController.darkModeEnabled.value = false;
      await tester.pumpWidget(const AppRoot());
      await tester.pump();
      final app = tester.widget<MaterialApp>(find.byType(MaterialApp));
      expect(app.themeMode, ThemeMode.light);
    });

    testWidgets('AppRoot switches to dark theme when darkMode enabled', (
      WidgetTester tester,
    ) async {
      SettingsController.darkModeEnabled.value = true;
      await tester.pumpWidget(const AppRoot());
      await tester.pump();
      final app = tester.widget<MaterialApp>(find.byType(MaterialApp));
      expect(app.themeMode, ThemeMode.dark);
      SettingsController.darkModeEnabled.value = false;
    });

    testWidgets('AppRoot does not show debug banner', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(const AppRoot());
      await tester.pump();
      final app = tester.widget<MaterialApp>(find.byType(MaterialApp));
      expect(app.debugShowCheckedModeBanner, false);
    });

    testWidgets('AppRoot app title is correct', (WidgetTester tester) async {
      await tester.pumpWidget(const AppRoot());
      await tester.pump();
      final app = tester.widget<MaterialApp>(find.byType(MaterialApp));
      expect(app.title, 'NASA Gallery App');
    });
  });
}
